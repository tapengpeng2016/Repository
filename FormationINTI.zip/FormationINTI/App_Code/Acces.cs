﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Description résumée de Acces
/// </summary>
public class Acces
{
    public int Id_acces;
    public string type_acces;

    public Acces()
    {
        //
        // TODO: Add constructor logic here
        //
    }
    public void AjouterAcces()
    {

    }
    public void ModifierAcces()
    {

    }
}