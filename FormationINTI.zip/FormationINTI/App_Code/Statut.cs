﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Description résumée de Statut
/// </summary>
public class Statut
{
    public int Id_statut;
    public string type_statut;

    public Statut()
    {
        //
        // TODO: Add constructor logic here
        //
    }
    public void ModifierStatut()
    {

    }
    public void VerifierStatut()
    {

    }
}