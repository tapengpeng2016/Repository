﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Description résumée de Historique_Connexion
/// </summary>
public class Historique_Connexion
{
    public int Id_historique_connexion;
   
    public string date_connexion;
    public string chemin_log;
    
    public Historique_Connexion()
    {
        //
        // TODO: Add constructor logic here
        //
    }
    public void EnregistrerConnexion()
    {

    }
    public string  ListerConnexion()
    {
        return "";
    }
}