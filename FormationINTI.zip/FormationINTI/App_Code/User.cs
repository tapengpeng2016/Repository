﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

/// <summary>
/// Personne s'est incrit en ligne
/// 2 statuts: en attente ou confirmation inscription
/// </summary>


public class User 
{
 public int Id_user;
    public int Id_acces;
    public int Id_statut;
    
  public string email;
   public string mdp;
    public string tel;
    const string str = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=Inscription;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=True;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";

    public User()
    {
       
    }

    public void EnregistrerInscription()
    {
       
     
       
       
    }
    public void ValiderInscription()
    {

    }
    public string GenererMDP()
    {
        return "";
    }

    public void SupprimerInscription()
    {

    }
    public void AfficherFormulaireInscription()
    {

    }
    public void AfficherFormulaireDesincription()
    {

    }
    public void ConnecterUser()
    {

    }
    public void DeconnecterUser()
    {

    }
    public string EnvoyerMSG()
    {
        return "";
    }
    public void VerifierIterationConnexion()
    {

    }
    public void VerifierEmail()
    {

    }
}