﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Description résumée de Image
/// </summary>
public class Image
{
    public int Id_image;
    public string nom_image;
    public string description_image;
    public string chemin_imgae;
    
    public Image()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    public void AjouterImage()
    {

    }
}