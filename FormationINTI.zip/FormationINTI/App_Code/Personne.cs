﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;





/// <summary>
/// Description résumée de Personne
/// </summary>
/// 



public class Personne
{
    public int Id_personne;
    public string civilite;
    public string nom;
    public string prenom;
   
   

    const string str= "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=PANNIER;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=True;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
    public Personne()
    {
        //
        // TODO: Add constructor logic here
        //
    }
    public int enregistrerPersonne(Personne p)
    {
        //SqlConncection

        //SqlCommand
        //close();
        SqlConnection cnx = new SqlConnection(str);
        cnx.Open();
        string sql ="SELECT TOP 1 Id_Personne FROM [dbo].[Personne] order by Id_Personne DESC";
        SqlCommand cmd = new SqlCommand(sql,cnx);
        cmd.CommandType = CommandType.Text;
        int id1= Convert.ToInt32(cmd.ExecuteScalar());
        cnx.Close();
        int id = id1 + 1;

        
        
        cnx.Open();
        string sql1 = "INSERT INTO [Personne](Id_Personne,civilite,Nom,Prenom) VALUES(" + id + ",'" + p.civilite + "', '" + p.nom + "','" + p.prenom + "')";
        SqlCommand cmd1 = new SqlCommand(sql1, cnx);
        cmd1.CommandType = CommandType.Text;
        cmd1.ExecuteNonQuery();
        cnx.Close();

        return id;
    }

    public void ModiferPersonne()
    {

    }
    public void SupprimerPersonne()
    {

    }
    public void VerifierPersonne()
    {

    }
    public void AfficherProfil()
    {

    }
    public void ModifierProfil()
    {

    }

}